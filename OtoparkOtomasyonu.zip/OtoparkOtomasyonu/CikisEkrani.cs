﻿using System;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OtoparkOtomasyonu
{
    public partial class CikisEkrani : Form
    {

        
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5H0TylT8eW1KoTKR207yo8K6HHkp8LVU0pdhkxTM",
            BasePath = "https://otopark-otomasyonu-6e7a7-default-rtdb.firebaseio.com"
        };
        IFirebaseClient client;

        // Hafızada tutacağımız araç (Polimorfizm için gerekli)
        Arac bulunanArac;
        double odenecekTutar = 0;

        public CikisEkrani()
        {
            InitializeComponent();
        }

        private void CikisEkrani_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
            }
            catch
            {
                MessageBox.Show("İnternet bağlantısı yok!");
            }
        }

        // 1. BUTON: SORGULA VE HESAPLA
        private async void btnSorgula_Click(object sender, EventArgs e)
        {
            string plaka = txtCikisPlaka.Text.ToUpper();

            // Firebase'den aracı çekiyoruz
            var response = await client.GetAsync("Araclar/" + plaka);

            // Eğer "Araclar/34ABC" diye bir şey yoksa 'null' döner
            if (response.Body != "null")
            {
                
                var data = response.ResultAs<dynamic>();

                string gelenTip = data.Tip;
                DateTime girisZamani = Convert.ToDateTime(data.GirisZamani);

                // --- POLİMORFİZM NOKTASI ---
                // Gelen tipe göre doğru sınıfı oluşturuyoruz.
                // Böylece Kamyon ise kamyon tarifesi, motor ise motor tarifesi çalışacak.
                if (gelenTip == "Otomobil") bulunanArac = new Otomobil();
                else if (gelenTip == "Kamyon") bulunanArac = new Kamyon();
                else bulunanArac = new Motor();

                // Bilgileri içine atalım
                bulunanArac.GirisSaati = girisZamani;
                bulunanArac.Plaka = plaka;

                // Süreyi Hesapla (Şu an - Giriş)
                TimeSpan sure = DateTime.Now - girisZamani;
                double toplamSaat = sure.TotalHours;

                // Ücreti Hesapla (Her sınıf kendi metodunu çalıştırır)
                double ucret = bulunanArac.UcretHesapla(toplamSaat);
                odenecekTutar = ucret; // Tutarı hafızaya aldık

                // Ekrana Yazdır
                lblTutar.Text = ucret.ToString("0.00") + " TL";
                MessageBox.Show($"Araç {Math.Ceiling(toplamSaat)} saattir içeride.");

                // Artık ödeme butonunu aktif edebiliriz
                btnOdeme.Enabled = true;
            }
            else
            {
                MessageBox.Show("Bu plakaya ait araç bulunamadı!");
                lblTutar.Text = "0.00 TL";
            }
        }

        // 2. BUTON: ÖDEME AL VE SİL

        private async void button2_Click(object sender, EventArgs e)
        {
            if (bulunanArac != null)
                // Parayı kasaya ekle
                Arac.ToplamKasa += odenecekTutar;
            {
                // 1. Aracı Veritabanından Sil
                await client.DeleteAsync("Araclar/" + txtCikisPlaka.Text.ToUpper());

                MessageBox.Show("Ödeme Alındı. Araç Çıkışı Yapıldı. İyi Yolculuklar!");

                // Ekranı temizle
                txtCikisPlaka.Text = "";
                lblTutar.Text = "0.00 TL";
                btnOdeme.Enabled = false;
                bulunanArac = null; // Hafızayı boşalt
            }
        }
    }
}
