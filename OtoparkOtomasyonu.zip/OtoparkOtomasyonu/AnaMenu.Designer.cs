﻿namespace OtoparkOtomasyonu
{
    partial class AnaMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGirisEkrani = new System.Windows.Forms.Button();
            this.btnCikisEkrani = new System.Windows.Forms.Button();
            this.BtnHasilat = new System.Windows.Forms.Button();
            this.btnMusteriYonetimi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGirisEkrani
            // 
            this.btnGirisEkrani.BackColor = System.Drawing.Color.White;
            this.btnGirisEkrani.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGirisEkrani.ForeColor = System.Drawing.Color.Black;
            this.btnGirisEkrani.Location = new System.Drawing.Point(132, 27);
            this.btnGirisEkrani.Name = "btnGirisEkrani";
            this.btnGirisEkrani.Size = new System.Drawing.Size(517, 90);
            this.btnGirisEkrani.TabIndex = 0;
            this.btnGirisEkrani.Text = "ARAÇ GİRİŞ";
            this.btnGirisEkrani.UseVisualStyleBackColor = false;
            this.btnGirisEkrani.Click += new System.EventHandler(this.btnGirisEkrani_Click);
            // 
            // btnCikisEkrani
            // 
            this.btnCikisEkrani.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCikisEkrani.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCikisEkrani.Location = new System.Drawing.Point(132, 223);
            this.btnCikisEkrani.Name = "btnCikisEkrani";
            this.btnCikisEkrani.Size = new System.Drawing.Size(517, 91);
            this.btnCikisEkrani.TabIndex = 1;
            this.btnCikisEkrani.Text = "ARAÇ ÇIKIŞ VE ÖDEME";
            this.btnCikisEkrani.UseVisualStyleBackColor = false;
            this.btnCikisEkrani.Click += new System.EventHandler(this.btnCikisEkrani_Click);
            // 
            // BtnHasilat
            // 
            this.BtnHasilat.BackColor = System.Drawing.Color.LightGray;
            this.BtnHasilat.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHasilat.Location = new System.Drawing.Point(132, 320);
            this.BtnHasilat.Name = "BtnHasilat";
            this.BtnHasilat.Size = new System.Drawing.Size(517, 94);
            this.BtnHasilat.TabIndex = 2;
            this.BtnHasilat.Text = "GÜNLÜK HASILAT";
            this.BtnHasilat.UseVisualStyleBackColor = false;
            this.BtnHasilat.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnMusteriYonetimi
            // 
            this.btnMusteriYonetimi.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMusteriYonetimi.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMusteriYonetimi.Location = new System.Drawing.Point(132, 123);
            this.btnMusteriYonetimi.Name = "btnMusteriYonetimi";
            this.btnMusteriYonetimi.Size = new System.Drawing.Size(517, 94);
            this.btnMusteriYonetimi.TabIndex = 3;
            this.btnMusteriYonetimi.Text = "MÜŞTERİ YÖNETİM";
            this.btnMusteriYonetimi.UseVisualStyleBackColor = false;
            this.btnMusteriYonetimi.Click += new System.EventHandler(this.btnMusteriYonetimi_Click);
            // 
            // AnaMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::OtoparkOtomasyonu.Properties.Resources.Gemini_Generated_Image_elepjmelepjmelep1;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMusteriYonetimi);
            this.Controls.Add(this.BtnHasilat);
            this.Controls.Add(this.btnCikisEkrani);
            this.Controls.Add(this.btnGirisEkrani);
            this.Name = "AnaMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ana Menü";
            this.Load += new System.EventHandler(this.AnaMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGirisEkrani;
        private System.Windows.Forms.Button btnCikisEkrani;
        private System.Windows.Forms.Button BtnHasilat;
        private System.Windows.Forms.Button btnMusteriYonetimi;
    }
}