﻿using System;

namespace OtoparkOtomasyonu
{
    // ANA SINIF
    public abstract class Arac
    {
        public static double ToplamKasa = 0;
        public string Plaka { get; set; }
        public string Tip { get; set; }
        public DateTime GirisSaati { get; set; }

       
        public double SaatlikUcret { get; set; } = 20.0;

      
        public virtual double UcretHesapla(double saat)
        {
            if (saat < 1) saat = 1;
           
            return saat * SaatlikUcret;
        }
    }

    // YAVRU SINIFLAR

    public class Otomobil : Arac
    {
        public Otomobil()
        {
            Tip = "Otomobil";
            SaatlikUcret = 20.0;
        }
    }

    public class Kamyon : Arac
    {
        public Kamyon()
        {
            Tip = "Kamyon";
            SaatlikUcret = 50.0;
        }

        public override double UcretHesapla(double saat)
        {
            if (saat < 1) saat = 1;
            // Kamyona özel +10 TL ekliyoruz
            return (saat * SaatlikUcret) + 10.0;
        }
    }

    public class Motor : Arac
    {
        public Motor()
        {
            Tip = "Motor";
            SaatlikUcret = 10.0;
        }
        public class Arac // veya kullandığınız temel sınıf
        {
            public string Plaka { get; set; }
            public string Tip { get; set; } // Bu, Araç Tipini tutmalı
            public DateTime GirisSaati { get; set; }

            // YENİ EKLENMESİ GEREKENLER:
            public string MusteriAd { get; set; }
            public string MusteriSoyad { get; set; }
        }
    }
}