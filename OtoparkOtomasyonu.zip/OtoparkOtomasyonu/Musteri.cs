﻿using System;

namespace OtoparkOtomasyonu
{
    public class Musteri
    {
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Plaka { get; set; }
        public string AracTipi { get; set; } // Sedan, SUV vb.
        public DateTime GirisSaati { get; set; }

        // Otomatik hesaplananlar
        public string ParkSuresi
        {
            get
            {
                if (GirisSaati == DateTime.MinValue) return "Hata";
                TimeSpan sure = DateTime.Now - GirisSaati;
                if (sure.TotalMinutes < 1) return "Yeni Giriş";
                return $"{(int)sure.TotalMinutes} Dakika";
            }
        }

        public string GuncelBorc
        {
            get
            {
                if (GirisSaati == DateTime.MinValue) return "0.00 TL";
                double saat = (DateTime.Now - GirisSaati).TotalHours;
                if (saat < 0) saat = 0;
                double ucret = Math.Ceiling(saat) * 20; // Saati 20 TL
                return $"{ucret:0.00} TL";
            }
        }
    }
}