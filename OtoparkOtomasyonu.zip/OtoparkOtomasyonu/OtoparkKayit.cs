﻿using System;
// Musteri.cs ve Araclar.cs sınıflarına artık ihtiyaç yok, ancak bu dosyaları silmeyin.

namespace OtoparkOtomasyonu
{
   
    public class OtoparkKayit // Düz yapı ve string GirisZamani önemli
    {
        public string KayitId { get; set; }
        public string MusteriAd { get; set; }
        public string MusteriSoyad { get; set; }
        public string Plaka { get; set; }
        public string Tip { get; set; }
        public string GirisZamani { get; set; } // string olmalı
        public string Durum { get; set; }
    }
}