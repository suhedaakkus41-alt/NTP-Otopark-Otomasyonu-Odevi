﻿using System;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OtoparkOtomasyonu
{
    public partial class GirisEkrani : Form
    {
        
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5H0TylT8eW1KoTKR207yo8K6HHkp8LVU0pdhkxTM",
            BasePath = "https://otopark-otomasyonu-6e7a7-default-rtdb.firebaseio.com"
        };

        IFirebaseClient client;

        public GirisEkrani()
        {
            InitializeComponent();
            txtSifre.PasswordChar = '*';
        }

        private void GirisEkrani_Load(object sender, EventArgs e)
        {
            
        }

        private async void btnGirisYap_Click(object sender, EventArgs e)
        {
            // Kutucuklar boş mu kontrolü
            if (string.IsNullOrEmpty(txtKullaniciAdi.Text) || string.IsNullOrEmpty(txtSifre.Text))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifre giriniz.");
                return;
            }

            try
            {
                
                if (client == null)
                {
                    client = new FireSharp.FirebaseClient(config);
                }

               
                FirebaseResponse response = await client.GetAsync("Kullanicilar/" + txtKullaniciAdi.Text);

                Kullanici gelenKullanici = response.ResultAs<Kullanici>();

               
                if (gelenKullanici != null && gelenKullanici.Sifre == txtSifre.Text)
                {
                    MessageBox.Show("Giriş Başarılı!");

                    // Ana Menüyü Aç
                    AnaMenu anaMenu = new AnaMenu();
                    anaMenu.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre hatalı!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void chkSifreyiGoster_CheckedChanged(object sender, EventArgs e)
        {
            // CheckBox işaretli ise (true), şifreyi göster.
            if (chkSifreyiGoster.Checked)
            {
                // Şifre karakterini boş olarak ayarlar, böylece metin görünür olur.
                txtSifre.PasswordChar = '\0'; 
            }
            else
            {
                // CheckBox işaretli değilse (false), şifreyi gizle.
                txtSifre.PasswordChar = '*';
            }
        }

        private void lblSifre_Click(object sender, EventArgs e)
        {

        }
    }
}