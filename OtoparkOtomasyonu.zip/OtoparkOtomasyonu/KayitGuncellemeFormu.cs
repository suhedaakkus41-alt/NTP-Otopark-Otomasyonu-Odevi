﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Newtonsoft.Json;

namespace OtoparkOtomasyonu
{
    public partial class KayitGuncellemeFormu : Form
    {

        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5H0TylT8eW1KoTKR207yo8K6HHkp8LVU0pdhkxTM", // Sizin AuthSecret'ınız
            BasePath = "https://otopark-otomasyonu-6e7a7-default-rtdb.firebaseio.com" // Sizin BasePath'iniz
        };
        IFirebaseClient client;

        // Bellekteki tüm kayıtları (Firebase Key ile) tutacak sözlük
        private Dictionary<string, OtoparkKayitData> _tumVeriSozlugu;
        private string _secilenKayitKey = null; // Güncellenecek kaydın Firebase ID'si

        public KayitGuncellemeFormu()
        {
            InitializeComponent();
            try
            {
                client = new FireSharp.FirebaseClient(config);
            }
            catch (Exception) { /* Bağlantı hatası olursa sessiz kal */ }
        }

        private async void KayitGuncellemeFormu_Load(object sender, EventArgs e)
        {
            await TabloyuDoldur();

            // Araç Tiplerini ComboBox'a yükleme (Gerekiyorsa)
            cmbAracTipi.Items.AddRange(new object[] { "Otomobil", "Kamyonet", "Motosiklet" });

            // Seçim olayını bağla
            dgvKayitlar.CellClick += dgvKayitlar_CellClick;
        }

        
        // 1. KAYITLARI ÇEKME VE DATATABLE'A DOLDURMA 
       
        private async System.Threading.Tasks.Task TabloyuDoldur()
        {
            if (client == null) return;
            try
            {
                FirebaseResponse response = await client.GetAsync("Araclar");

                if (response.Body != "null" && response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    //  Firebase'den gelen veriyi ID (string) ve OtoparkKayitData (Value) olarak al
                    _tumVeriSozlugu = JsonConvert.DeserializeObject<Dictionary<string, OtoparkKayitData>>(response.Body);
                    DataTable tablo = new DataTable();
                    tablo.Columns.Add("KEY", typeof(string));
                    tablo.Columns.Add("PLAKA", typeof(string));
                    tablo.Columns.Add("MÜŞTERİ ADI", typeof(string));
                    tablo.Columns.Add("MÜŞTERİ SOYADI", typeof(string));
                    tablo.Columns.Add("TİP", typeof(string));
                    tablo.Columns.Add("GİRİŞ SAATİ", typeof(string));
                    tablo.Columns.Add("SÜRE", typeof(string)); 
                    if (_tumVeriSozlugu == null) return;

                    foreach (var item in _tumVeriSozlugu)
                    {
                        OtoparkKayitData veri = item.Value;

                        //  SÜRE HESAPLAMA BAŞLANGICI 

                        // GirisZamani'nı DateTime tipine çeviriyoruz
                        DateTime girisZamani = veri.GirisZamani;

                        // TimeSpan: Şu anki zaman ile giriş zamanı arasındaki farkı hesaplar
                        TimeSpan icerideKalmaSuresi = DateTime.Now.Subtract(girisZamani);

                        // Süreyi okunabilir formata çevirme
                        string sureFormatli = $"{icerideKalmaSuresi.Days} Gün, {icerideKalmaSuresi.Hours} Saat, {icerideKalmaSuresi.Minutes} Dk";

                        //  SÜRE HESAPLAMA SONU 

                        tablo.Rows.Add(
                            item.Key,
                            veri.Plaka,
                            veri.MusteriAd,
                            veri.MusteriSoyad,
                            veri.Tip,
                            veri.GirisZamani.ToString("dd.MM.yyyy HH:mm"),
                            sureFormatli 
                        );
                    }

                    // gridAraclar.DataSource = tablo; /
                    dgvKayitlar.DataSource = tablo;

                    // KEY sütununu gizle (Kullanıcı görmemeli)
                    if (dgvKayitlar.Columns.Contains("KEY"))
                    {
                        dgvKayitlar.Columns["KEY"].Visible = false;
                    }
                }
                else
                {
                    MessageBox.Show("Veritabanında aktif kayıt bulunamadı veya yetki hatası.", "Bilgi");
                    dgvKayitlar.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message, "Kritik Hata");
            }
        }

        
        // 2. SATIRA TIKLANDIĞINDA KUTULARI DOLDURMA
        
        private void dgvKayitlar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvKayitlar.Rows[e.RowIndex];
            _secilenKayitKey = row.Cells["KEY"].Value?.ToString();

            if (_secilenKayitKey != null && _tumVeriSozlugu.ContainsKey(_secilenKayitKey))
            {
                OtoparkKayitData secilenVeri = _tumVeriSozlugu[_secilenKayitKey];

                txtAd.Text = secilenVeri.MusteriAd;
                txtSoyad.Text = secilenVeri.MusteriSoyad;
                txtPlaka.Text = secilenVeri.Plaka;
                txtPlaka.Enabled = false;

                cmbAracTipi.SelectedItem = secilenVeri.Tip;
            }
        }


        
        // 3. GÜNCELLE BUTONU İŞLEMİ
        
        private async void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (_secilenKayitKey == null)
            {
                MessageBox.Show("Lütfen listeden güncellenecek bir kayıt seçin.", "Uyarı");
                return;
            }
            if (string.IsNullOrWhiteSpace(txtAd.Text))
            {
                MessageBox.Show("Müşteri Adı zorunludur.", "Uyarı");
                return;
            }

            // Bellekteki veriyi bul ve güncelle
            OtoparkKayitData guncellenecekVeri = _tumVeriSozlugu[_secilenKayitKey];

            guncellenecekVeri.MusteriAd = txtAd.Text.Trim();
            guncellenecekVeri.MusteriSoyad = txtSoyad.Text.Trim();
            guncellenecekVeri.Tip = cmbAracTipi.SelectedItem?.ToString();
            // Plaka değişmediği için güncellemeye gerek yok

            try
            {
                // Firebase'e sadece ilgili Key'i güncelleyerek geri yaz
                SetResponse response = await client.SetAsync($"Araclar/{_secilenKayitKey}", guncellenecekVeri);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    MessageBox.Show("Kayıt başarıyla güncellendi!");
                    await TabloyuDoldur(); // Tabloyu yenile
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Güncelleme sırasında hata oluştu: " + ex.Message, "Hata");
            }
        }

        //  MODEL SINIFI 
        public class OtoparkKayitData
        {
            // Firebase'den gelen tüm alanları birebir eşleştirir
            public string MusteriAd { get; set; }
            public string MusteriSoyad { get; set; }
            public string Plaka { get; set; }
            public string Tip { get; set; }
            // Firebase'de string olsa bile, JsonConvert genellikle bunu DateTime'a çevirebilir
            public DateTime GirisZamani { get; set; }
            public string Durum { get; set; }
        }

        private void dgvKayitlar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Başlık satırına tıklamayı engelle
    if (e.RowIndex < 0 || dgvKayitlar.Rows.Count == 0) return;

    // 
    DataGridViewRow row = dgvKayitlar.Rows[e.RowIndex];

    // 1. Firebase Key'i (ID) al
    string secilenKey = row.Cells["KEY"].Value?.ToString(); 
    _secilenKayitKey = secilenKey;

    // 2. Eğer ID varsa, detayları doldur
    if (secilenKey != null && _tumVeriSozlugu.ContainsKey(secilenKey))
    {
        // Bellekteki tüm veriyi çekelim (Çünkü DataGridView'de birleştirilmiş alanlar var)
        OtoparkKayitData secilenVeri = _tumVeriSozlugu[secilenKey];
        
        // Formdaki Textbox'ları doldur
        txtAd.Text = secilenVeri.MusteriAd;      
        txtSoyad.Text = secilenVeri.MusteriSoyad;
        txtPlaka.Text = secilenVeri.Plaka;
        
        // Plaka anahtar olduğu için kilitliyoruz )
        txtPlaka.Enabled = false;

                // Araç tipini ComboBox'ta seç
                cmbAracTipi.SelectedItem = secilenVeri.Tip;

    }
        }
    }
}