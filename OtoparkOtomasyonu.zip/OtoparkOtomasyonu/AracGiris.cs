﻿using System;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace OtoparkOtomasyonu
{
    public partial class AracGiris : Form
    {
        
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "5H0TylT8eW1KoTKR207yo8K6HHkp8LVU0pdhkxTM",
            BasePath = "https://otopark-otomasyonu-6e7a7-default-rtdb.firebaseio.com"
        };

        IFirebaseClient client;

        public AracGiris()
        {
            InitializeComponent();
        }

       
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                if (client == null)
                {
                    MessageBox.Show("Bağlantı Kurulamadı! İnternetini kontrol et.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bağlantı Hatası: " + ex.Message);
            }
        }

      
        private async void btnGiris_Click(object sender, EventArgs e)
        {
            // 1. GÜNCELLENMİŞ Boş alan kontrolü (Müşteri Adı ve Soyadı eklendi)
            if (string.IsNullOrEmpty(txtPlaka.Text) ||
                string.IsNullOrEmpty(cmbTip.Text) ||
                string.IsNullOrEmpty(txtMusteriAd.Text) || // Yeni Kontrol
                string.IsNullOrEmpty(txtMusteriSoyad.Text)) // Yeni Kontrol
            {
                MessageBox.Show("Lütfen Müşteri Adı, Soyadı, Plaka ve araç tipi seçiniz!");
                return;
            }

            // Müşteri ad ve soyadını önceden alalım
            string musteriAd = txtMusteriAd.Text.Trim();
            string musteriSoyad = txtMusteriSoyad.Text.Trim();

            { } // 2. OOP KULLANIMI  Polimorfizm ve kalıtım
            // Hangi tipi seçtiyse o sınıftan nesne üretiyoruz
            Arac yeniArac = null;

            if (cmbTip.Text == "Otomobil")
            {
                yeniArac = new Otomobil();
            }
            else if (cmbTip.Text == "Kamyon")
            {
                yeniArac = new Kamyon();
            }
            else
            {
                yeniArac = new Motor();
            }

            // Bilgileri dolduruyoruz
            yeniArac.Plaka = txtPlaka.Text.ToUpper(); // Büyük harf yap
            yeniArac.GirisSaati = DateTime.Now;

           
            var kayitVerisi = new
            {
                MusteriAd = musteriAd,        
                MusteriSoyad = musteriSoyad,  
                Plaka = yeniArac.Plaka,
                Tip = yeniArac.Tip,
                GirisZamani = yeniArac.GirisSaati.ToString("yyyy-MM-dd HH:mm:ss"), 
                Durum = "Otoparkta"
            };

            try
            {
                
                // "Araclar" klasörünün içine, Plakayı başlık yaparak kaydediyoruz.
                var response = await client.SetAsync("Araclar/" + yeniArac.Plaka, kayitVerisi);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    MessageBox.Show($"Müşteri: {musteriAd} {musteriSoyad} için Araç Girişi Başarılı!");

                    // Kutuları temizle
                    txtPlaka.Text = "";
                    txtMusteriAd.Text = "";   
                    txtMusteriSoyad.Text = "";
                    cmbTip.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt Hatası: " + ex.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}