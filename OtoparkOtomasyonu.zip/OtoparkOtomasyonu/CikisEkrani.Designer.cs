﻿namespace OtoparkOtomasyonu
{
    partial class CikisEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cikisYapacakArac = new System.Windows.Forms.Label();
            this.txtCikisPlaka = new System.Windows.Forms.TextBox();
            this.btnSorgula = new System.Windows.Forms.Button();
            this.lblTutar = new System.Windows.Forms.Label();
            this.btnOdeme = new System.Windows.Forms.Button();
            this.lblIslemTurtari = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cikisYapacakArac
            // 
            this.cikisYapacakArac.AutoSize = true;
            this.cikisYapacakArac.BackColor = System.Drawing.Color.Transparent;
            this.cikisYapacakArac.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cikisYapacakArac.ForeColor = System.Drawing.Color.White;
            this.cikisYapacakArac.Location = new System.Drawing.Point(163, 75);
            this.cikisYapacakArac.Name = "cikisYapacakArac";
            this.cikisYapacakArac.Size = new System.Drawing.Size(182, 28);
            this.cikisYapacakArac.TabIndex = 0;
            this.cikisYapacakArac.Text = "Çıkış Yapacak Araç";
            // 
            // txtCikisPlaka
            // 
            this.txtCikisPlaka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCikisPlaka.Location = new System.Drawing.Point(396, 69);
            this.txtCikisPlaka.Name = "txtCikisPlaka";
            this.txtCikisPlaka.Size = new System.Drawing.Size(250, 38);
            this.txtCikisPlaka.TabIndex = 1;
            // 
            // btnSorgula
            // 
            this.btnSorgula.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSorgula.Location = new System.Drawing.Point(261, 138);
            this.btnSorgula.Name = "btnSorgula";
            this.btnSorgula.Size = new System.Drawing.Size(245, 75);
            this.btnSorgula.TabIndex = 2;
            this.btnSorgula.Text = "Sorgula ve Hesapla";
            this.btnSorgula.UseVisualStyleBackColor = true;
            this.btnSorgula.Click += new System.EventHandler(this.btnSorgula_Click);
            // 
            // lblTutar
            // 
            this.lblTutar.AutoSize = true;
            this.lblTutar.BackColor = System.Drawing.Color.White;
            this.lblTutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTutar.Location = new System.Drawing.Point(391, 260);
            this.lblTutar.Name = "lblTutar";
            this.lblTutar.Size = new System.Drawing.Size(87, 29);
            this.lblTutar.TabIndex = 3;
            this.lblTutar.Text = "0.00TL";
            // 
            // btnOdeme
            // 
            this.btnOdeme.Font = new System.Drawing.Font("Bahnschrift SemiBold Condensed", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOdeme.Location = new System.Drawing.Point(242, 341);
            this.btnOdeme.Name = "btnOdeme";
            this.btnOdeme.Size = new System.Drawing.Size(287, 80);
            this.btnOdeme.TabIndex = 4;
            this.btnOdeme.Text = "Ödeme Al Ve Çık";
            this.btnOdeme.UseVisualStyleBackColor = true;
            this.btnOdeme.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblIslemTurtari
            // 
            this.lblIslemTurtari.AutoSize = true;
            this.lblIslemTurtari.BackColor = System.Drawing.Color.Transparent;
            this.lblIslemTurtari.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIslemTurtari.ForeColor = System.Drawing.Color.White;
            this.lblIslemTurtari.Location = new System.Drawing.Point(250, 263);
            this.lblIslemTurtari.Name = "lblIslemTurtari";
            this.lblIslemTurtari.Size = new System.Drawing.Size(101, 24);
            this.lblIslemTurtari.TabIndex = 5;
            this.lblIslemTurtari.Text = "İşlem Tutarı";
            // 
            // CikisEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::OtoparkOtomasyonu.Properties.Resources.Gemini_Generated_Image_elepjmelepjmelep1;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblIslemTurtari);
            this.Controls.Add(this.btnOdeme);
            this.Controls.Add(this.lblTutar);
            this.Controls.Add(this.btnSorgula);
            this.Controls.Add(this.txtCikisPlaka);
            this.Controls.Add(this.cikisYapacakArac);
            this.Name = "CikisEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Çıkış Ekranı";
            this.Load += new System.EventHandler(this.CikisEkrani_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cikisYapacakArac;
        private System.Windows.Forms.TextBox txtCikisPlaka;
        private System.Windows.Forms.Button btnSorgula;
        private System.Windows.Forms.Label lblTutar;
        private System.Windows.Forms.Button btnOdeme;
        private System.Windows.Forms.Label lblIslemTurtari;
    }
}