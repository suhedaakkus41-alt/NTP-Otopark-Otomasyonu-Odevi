﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtoparkOtomasyonu
{
    public partial class AnaMenu : Form
    {
        public AnaMenu()
        {
            InitializeComponent();
        }

        private void AnaMenu_Load(object sender, EventArgs e)
        {

        }

        private void btnGirisEkrani_Click(object sender, EventArgs e)
        {
            AracGiris giris = new AracGiris();
            giris.ShowDialog();
        }

        private void btnCikisEkrani_Click(object sender, EventArgs e)
        {
            CikisEkrani cikis = new CikisEkrani();
            cikis.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kasada Biriken Toplam Tutar: " + Arac.ToplamKasa.ToString("0.00") + " TL");
        }

        private void btnMusteriYonetimi_Click(object sender, EventArgs e)
        {
            KayitGuncellemeFormu ekran = new KayitGuncellemeFormu();
            ekran.Show();
        }
    }
}
